# Jira Agent

This agent connects to Jira to create and manage issues, such as user stories, epics, and tasks. It can also read existing issues to provide context and suggest how to structure new items.
