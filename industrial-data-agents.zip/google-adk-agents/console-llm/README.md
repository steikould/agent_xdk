# Console-Based LLM

This is a console-based LLM that allows a user to interact with the results from the SharePoint agent. This allows for discussion and iteration on ticket ideas to ensure accuracy before creating them in Azure DevOps or Jira.
