# Azure DevOps Agent

This agent connects to Azure DevOps to create and manage work items, such as user stories, epics, and tasks. It can also read existing work items to provide context and suggest how to structure new items.
