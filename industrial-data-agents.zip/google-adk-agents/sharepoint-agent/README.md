# SharePoint Agent

This agent examines a SharePoint site for data engineering technical documents, diagrams, and other artifacts. It can then reason on the architecture and develop plans to incorporate into the tickets created by the Azure DevOps or Jira agents.
