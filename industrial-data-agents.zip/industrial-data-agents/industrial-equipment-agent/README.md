# Industrial Equipment Agent

This agent has access to a specific SharePoint site containing industrial equipment specifications, technical literature, and other documents related to the nature, operations, and maintenance of industrial pipelines. It provides this information to other agents to inform their understanding of the physical assets.
